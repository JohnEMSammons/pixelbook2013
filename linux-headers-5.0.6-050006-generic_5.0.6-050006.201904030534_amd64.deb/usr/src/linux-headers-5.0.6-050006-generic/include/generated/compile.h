/* This file is auto generated, version 201904030534 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201904030534 SMP Wed Apr 3 05:36:14 UTC 2019"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 8.3.0 (Ubuntu 8.3.0-4ubuntu1)"
